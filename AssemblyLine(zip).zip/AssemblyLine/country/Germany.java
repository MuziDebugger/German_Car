package com.generics.country;

public class Germany {

	private String model;
	public Germany(String model) {
		this.model = model;
		}

	public String getModel() {
		return model;
	}

}
