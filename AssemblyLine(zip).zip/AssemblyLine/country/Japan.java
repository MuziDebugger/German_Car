package com.generics.country;

public class Japan {

	private String model;
	public Japan(String model) {
		this.model = model;
		}

	public String getModel() {
		return model;
	}


}
