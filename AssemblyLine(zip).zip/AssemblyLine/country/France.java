package com.generics.country;

public class France {


	private String model;
	public France(String model) {
		this.model = model;
		}

	public String getModel() {
		return model;
	}



}
