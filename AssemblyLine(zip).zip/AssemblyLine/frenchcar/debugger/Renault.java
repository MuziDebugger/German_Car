package com.generics.frenchcar.debugger;

public class Renault extends French_Car {
	public Renault(String model) {
		super(model);
	}
}
