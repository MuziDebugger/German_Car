package com.generics.frenchcar.debugger;
import java.util.*;
public class AssemblyLine {
	
	private List <French_Car> frenchcar = new ArrayList<>();
	
	

}
