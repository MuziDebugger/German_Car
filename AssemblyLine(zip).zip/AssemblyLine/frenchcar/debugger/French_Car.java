package com.generics.frenchcar.debugger;

public class French_Car {
		private String model;
		public French_Car(String model) {
			this.model = model;
			}

		public String getModel() {
			return model;
		}
	}
