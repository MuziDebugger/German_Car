package com.generics.assembly;

import java.util.ArrayList;

public class AssemblyLine<T> {


	private String modelname;
	int numcars;
	private ArrayList <T> assembly = new ArrayList<>();
	
	public AssemblyLine (String modelname) {
		this.modelname = modelname;
	}

	public String getModelname() {
		return modelname;
	}
	 
	public boolean addCar(T car) {
		if(assembly.contains(car)) {
		return false;
		// if on file do not add to assembly line
	} else {
		assembly.add(car);
		return true;
		// nice!
	}
}
		public int numCars() {
		return this.assembly.size();
 }

}
