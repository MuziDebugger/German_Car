package com.generics.germancar.debugger;

public abstract class German_Car {
	private String model;
	
	public German_Car(String model) {
		this.model = model;
		}

	public String getModel() {
		return model;
	}
}
