package com.generics.germancar.debugger;

public class Mercedes_Benz extends German_Car {

	public Mercedes_Benz(String model) {
		super(model);
	}
}
