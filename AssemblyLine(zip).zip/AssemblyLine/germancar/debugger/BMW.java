package com.generics.germancar.debugger;

public class BMW extends German_Car {

	public BMW(String model) {
		super(model);
	}
}
