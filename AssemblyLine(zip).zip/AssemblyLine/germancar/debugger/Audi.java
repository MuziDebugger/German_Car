package com.generics.germancar.debugger;

public class Audi extends German_Car {

	public Audi(String model) {
		super(model);
	}
}
