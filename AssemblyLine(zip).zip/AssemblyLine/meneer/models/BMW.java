package com.generics.meneer.models;

import com.generics.country.Germany;

public class BMW extends Germany {

	public BMW(String model) {
		super(model);
	}

}
