package com.generics.meneer.models;

import com.generics.country.Japan;

public class Nissan extends Japan {

	public Nissan(String model) {
		super(model);
		// TODO Auto-generated constructor stub
	}

}
