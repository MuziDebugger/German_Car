package com.generics.meneer.models;

import com.generics.country.Germany;

public class MercedesBenz extends Germany {

	public MercedesBenz(String model) {
		super(model);
	}

}
