package com.generics.meneer.models;

import com.generics.country.France;

public class Renault extends France {

	public Renault(String model) {
		super(model);
		// TODO Auto-generated constructor stub
	}

}
