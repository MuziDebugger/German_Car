package com.generics.meneer.models;

import com.generics.country.Japan;

public class Toyota extends Japan {

	public Toyota(String model) {
		super(model);
		// TODO Auto-generated constructor stub
	}

}
